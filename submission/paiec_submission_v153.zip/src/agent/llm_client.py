"""Multi-provider stdlib LLM client for BLE (NVIDIA NIM -> Kilo AI -> OpenRouter).

Uses pure Python urllib.request with automatic failover and zero external SDK
dependencies. Supports tool calling and forces non-thinking fast mode on
Nemotron-3-Super-120B so turns complete within a few seconds.
"""

import json
import os
import time
import urllib.error
import urllib.request
from types import SimpleNamespace

from config.config import AgentConfig


def _get_endpoints():
    endpoints = []
    kilo_key = os.environ.get("KILO_API_KEY", "").strip()
    if kilo_key:
        endpoints.append({
            "name": "kilo",
            "url": "https://api.kilo.ai/api/gateway/v1/chat/completions",
            "key": kilo_key,
            "model": "nvidia/nemotron-3-super-120b-a12b:free",
            "timeout": 12.0,
            "extra": {"reasoning": {"enabled": False}},
        })
    or_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if or_key:
        endpoints.append({
            "name": "openrouter",
            "url": "https://openrouter.ai/api/v1/chat/completions",
            "key": or_key,
            "model": "nvidia/nemotron-3-super-120b-a12b:free",
            "timeout": 12.0,
            "extra": {"reasoning": {"enabled": False}},
        })
    nv_key = os.environ.get("NVIDIA_API_KEY", "").strip()
    if nv_key:
        endpoints.append({
            "name": "nvidia",
            "url": "https://integrate.api.nvidia.com/v1/chat/completions",
            "key": nv_key,
            "model": "nvidia/nemotron-3-super-120b-a12b",
            "timeout": 12.0,
            "extra": {"chat_template_kwargs": {"enable_thinking": False}},
        })
    return endpoints


_CORE_TOOLS = {"submit", "find_model", "search_benchmarks", "search_items"}


def complete_turn(
    messages: list,
    tools: list,
    config: AgentConfig,
    remaining_seconds: float,
    force_submit: bool,
):
    """Execute one BLE turn across Kilo AI -> OpenRouter -> NVIDIA NIM."""
    endpoints = _get_endpoints()
    if not endpoints:
        raise RuntimeError("No LLM API keys configured for BLE")

    active_tools = (
        tools
        if force_submit
        else [t for t in tools if t.get("function", {}).get("name") in _CORE_TOOLS]
    ) or tools

    last_err = None
    for ep in endpoints:
        rem = min(max(float(remaining_seconds), 4.0), float(ep["timeout"]))
        if force_submit:
            tc_mode = (
                "auto"
                if ep["name"] == "nvidia"
                else {"type": "function", "function": {"name": "submit"}}
            )
        else:
            tc_mode = "auto" if ep["name"] == "nvidia" else "required"
        body = {
            "model": ep["model"],
            "messages": messages,
            "tools": active_tools,
            "tool_choice": tc_mode,
            "temperature": 0.1,
            "max_tokens": min(int(config.max_tokens or 500), 500),
            **ep["extra"],
        }
        data = json.dumps(body).encode("utf-8")
        headers = {
            "Authorization": f"Bearer {ep['key']}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "PAIEC-BLE-Agent/1.0",
        }
        req = urllib.request.Request(ep["url"], data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=rem) as resp:
                raw = json.loads(resp.read().decode("utf-8"))
            choices = raw.get("choices") or []
            if not choices:
                continue
            msg = choices[0].get("message") or {}
            raw_tcs = msg.get("tool_calls") or []
            if not raw_tcs:
                continue
            tool_calls = []
            for idx, tc in enumerate(raw_tcs[:1]):
                fn = tc.get("function") or {}
                tool_calls.append(
                    SimpleNamespace(
                        id=tc.get("id") or f"call_{idx}",
                        function=SimpleNamespace(
                            name=fn.get("name") or "",
                            arguments=fn.get("arguments") if isinstance(fn.get("arguments"), str) else json.dumps(fn.get("arguments") or {}),
                        ),
                    )
                )
            usage = raw.get("usage") or {}
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(
                            role="assistant",
                            content=msg.get("content") or "",
                            tool_calls=tool_calls,
                            provider_specific_fields={},
                        )
                    )
                ],
                usage=SimpleNamespace(
                    prompt_tokens=int(usage.get("prompt_tokens") or 0),
                    completion_tokens=int(usage.get("completion_tokens") or 0),
                    total_tokens=int(usage.get("total_tokens") or 0),
                ),
            )
        except Exception as exc:
            last_err = exc
            continue

    raise RuntimeError(f"All BLE LLM endpoints failed: {last_err}")
